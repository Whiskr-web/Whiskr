import './textingBubble.css' 
import profilePicture from './image.png'

function TextingBubble(){

    return (
        <>

        <div class="textingBubble">
            <div class = "textingHeader">
                <div class = "headerText">
                    Your Messages
                </div>  
            </div>
            <div class = "seenPeopleTexting">
                <img src={profilePicture} className="profilePicture" alt="Profile" />
                <div className = "seenPeopleText"> Hey you look really cute... </div>
            </div>

            <div class = "unseenPeopleTexting">
                <img src={profilePicture} className="profilePicture" alt="Profile" />
                <div className = "unseenPeopleText"> So you down to get coffee later? </div>
            </div>
            <div class = "unseenPeopleTexting">
                <img src={profilePicture} className="profilePicture" alt="Profile" />
                <div className = "unseenPeopleText"> *Insert flirtatious line* </div>
            </div>
            <div class = "unseenPeopleTexting">
                <img src={profilePicture} className="profilePicture" alt="Profile" />
                <div className = "unseenPeopleText"> *Insert flirtatious line* </div>
            </div>
            <div class = "unseenPeopleTexting">
                <img src={profilePicture} className="profilePicture" alt="Profile" />
                <div className = "unseenPeopleText"> *Insert flirtatious line* </div>
            </div>
        </div>

        </>
    );
}

export default TextingBubble