import './App.css' 
import TextingBubble from './textingBubble.jsx' 
import SwipingPanel from './swipingPanel.jsx' 
import Switching from "./switching.jsx"

function App() {

  return (
    <div className='exterior'>
      <div className='PanelTotal'>
        <TextingBubble/>
        <SwipingPanel/>
        <Switching/>
      </div>
    </div>
  )
}

export default App
