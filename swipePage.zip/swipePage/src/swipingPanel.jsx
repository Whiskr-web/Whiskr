import './swipingPanel.css' 

import dogWithGirl from './girlWithDog.png'
import X from './X.png'
import heart from './heart.png'
import lightning from './lightning.jpg'

function SwipingPanel() {
  return (
    <>
        <div class="swipingPanel">
        <img src={dogWithGirl} className="whiskrSelfie" alt="Profile" />
        <div className = "portfolioText">
            <div className ="name">Sarah and Jester </div>
            <div className ="distance"> 10km away from you</div>
            <div className ="descriptioon"> Hiking trails, cozy nights, and adventures with Jester. Love dogs and good laughs? Let’s connect!</div>
        </div>
        <div className = "portfolioBubbles">
            <img src={X} alt="Image 1"/>
            <img src={heart} alt="Image 2"/>
            <img src={lightning} alt="Image 3"/>
        </div>
        </div>
    </>
  )
}

export default SwipingPanel
