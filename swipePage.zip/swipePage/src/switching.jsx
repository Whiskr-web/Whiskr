import dogIcon from './dog.png'
import './switching.css' 
function Switching() {
    return (
      <div className="switchingPanel">
          <img src={dogIcon} alt="dog" className='icon'/>
          <br>
          </br>
          You are currently looking for human dates. <br></br>
          Looking for pet date? Click to switch!
      </div>
      )
    }

    export default Switching